package robin.service.impl;

import com.robinche.service.HelloService2;
import org.apache.dubbo.config.annotation.Service;
import org.apache.dubbo.rpc.RpcContext;

import java.util.Map;

//@DubboService
@Service
public class HelloService2Impl implements HelloService2 {

    @Override
    public String sayHello(String name) {
        Map<String, String> attachments = RpcContext.getContext().getAttachments();
        String requestIp = attachments.get("requestIp");
        System.out.println("hello2中打印requestIp为：" + requestIp);
        return "hello2," + name;
    }
}
