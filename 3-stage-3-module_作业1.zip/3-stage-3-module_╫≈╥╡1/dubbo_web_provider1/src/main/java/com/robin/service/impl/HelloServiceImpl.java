package com.robin.service.impl;

import com.robinche.service.HelloService;
import org.apache.dubbo.config.annotation.Service;
import org.apache.dubbo.rpc.RpcContext;

import java.util.Map;

//@DubboService
@Service
public class HelloServiceImpl implements HelloService {

    @Override
    public String sayHello(String name) {
        Map<String, String> attachments = RpcContext.getContext().getAttachments();
        String requestIp = attachments.get("requestIp");
        System.out.println("hello1中打印requestIp为：" + requestIp);
        return "hello1," + name;
    }
}
