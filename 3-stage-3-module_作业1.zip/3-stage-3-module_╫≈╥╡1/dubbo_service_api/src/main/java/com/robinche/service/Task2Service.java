package com.robinche.service;

public interface Task2Service {

    public String methodA(String name);


    public String methodB(String name);


    public String methodC(String name);

}
