package com.robinche.service;

public interface HelloService2 {

    String sayHello(String name);

}
