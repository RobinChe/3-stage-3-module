package com.robinche.controller;

import com.robinche.service.HelloService;
import com.robinche.service.HelloService2;
import org.apache.dubbo.config.annotation.Reference;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/task1")
public class DubboRpcController {

    @Reference
    private HelloService helloService;

    @Reference
    private HelloService2 helloService2;

    @GetMapping("/{name}")
    public String test(@PathVariable("name") String name) {
        String result = helloService.sayHello(name);
        String result2 = helloService2.sayHello(name);
        return result + "," + result2;
    }

}
