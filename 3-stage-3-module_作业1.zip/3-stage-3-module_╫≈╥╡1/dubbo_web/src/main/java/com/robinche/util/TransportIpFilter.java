package com.robinche.util;

import org.apache.dubbo.common.constants.CommonConstants;
import org.apache.dubbo.common.extension.Activate;
import org.apache.dubbo.rpc.*;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;
import java.util.Map;


@Activate(group = {CommonConstants.CONSUMER})
public class TransportIpFilter implements Filter {

    @Override
    public Result invoke(Invoker<?> invoker, Invocation invocation) throws RpcException {

        //在IpFilter中获取http的request对象，并保存到RpcContext中
        HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
        if(request != null) {
            Map<String, String> attachments = RpcContext.getContext().getAttachments();
            attachments.put("requestIp", request.getRemoteAddr());
            //attachments.put("requestIp", "127.0.0.1");
        }

        return invoker.invoke(invocation);
    }
}
