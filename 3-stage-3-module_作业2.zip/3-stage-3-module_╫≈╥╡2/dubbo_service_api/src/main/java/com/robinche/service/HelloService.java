package com.robinche.service;

public interface HelloService {

    String sayHello(String name);

}
