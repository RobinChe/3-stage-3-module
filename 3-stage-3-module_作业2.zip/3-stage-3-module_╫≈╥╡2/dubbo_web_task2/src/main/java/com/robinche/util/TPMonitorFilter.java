package com.robinche.util;

import com.robinche.bean.MethodInfo;
import org.apache.dubbo.common.constants.CommonConstants;
import org.apache.dubbo.common.extension.Activate;
import org.apache.dubbo.rpc.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;


@Activate(group = {CommonConstants.CONSUMER})
public class TPMonitorFilter implements Filter {

    public static Map<String, List<MethodInfo>> methodTimesMap = new ConcurrentHashMap<>();

    @Override
    public Result invoke(Invoker<?> invoker, Invocation invocation) throws RpcException {

        Result result = null;
        Long costTime = 0L;

        try {
            Long startTime = System.currentTimeMillis();
            result =invoker.invoke(invocation);

            if(result.getException() instanceof Exception) {
                throw new Exception(result.getException());
            }
            costTime = System.currentTimeMillis() - startTime;
        } catch (Exception e) {
            e.printStackTrace();
            return result;
        }

        String methodName = invocation.getMethodName();
        List<MethodInfo> methodInfos = methodTimesMap.get(methodName);
        if(methodInfos == null) {
            methodInfos = new ArrayList<>();
            methodTimesMap.put(methodName, methodInfos);
        }
        methodInfos.add(new MethodInfo(methodName, costTime, System.currentTimeMillis()));

        return result;
    }
}
