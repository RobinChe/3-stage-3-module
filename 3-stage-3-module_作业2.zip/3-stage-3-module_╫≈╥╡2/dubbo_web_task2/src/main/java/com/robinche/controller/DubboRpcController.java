package com.robinche.controller;

import com.robinche.service.Task2Service;
import org.apache.dubbo.config.annotation.Reference;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@RestController
@RequestMapping("/task2")
public class DubboRpcController {

    @Reference
    private Task2Service task2Service;

    private ExecutorService executorService = null;
    private int MAX_TIMES = 10000;

    @GetMapping("/{name}")
    public String test(@PathVariable("name") String name) throws Exception{
        executorService = Executors.newFixedThreadPool(30);
        for (int i = 0; i < MAX_TIMES; i++) {
            Thread.sleep(20);
            executorService.submit(() -> { task2Service.methodA(name); });
            executorService.submit(() -> { task2Service.methodB(name); });
            executorService.submit(() -> { task2Service.methodC(name); });
        }

        return "执行完成!";
    }


}
