package com.robinche.service;

import com.robinche.bean.MethodInfo;
import com.robinche.util.TPMonitorFilter;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

@Component
public class TPMonitorThreadService {


    private ScheduledExecutorService scheduledExecutorService;

    @PostConstruct
    public void init() {
        System.out.println("初始化TP监控定时线程...");
        scheduledExecutorService = Executors.newSingleThreadScheduledExecutor();
        scheduledExecutorService.scheduleAtFixedRate(new TPMonitorThread(), 5,5, TimeUnit.SECONDS);
        System.out.println("初始化TP监控定时线程成功...");
    }

    private Long getTP(String methodName, List<MethodInfo> methodInfos, double rate) {
        //构建一个临时数组保存满足最近1分钟以内的数据
        List<MethodInfo> sortInfo = new ArrayList<>();
        long endTime = System.currentTimeMillis();
        long startTime = System.currentTimeMillis() - 60000;

        //遍历集合
        for (int i=0; i<methodInfos.size(); i++) {
            MethodInfo methodInfo = methodInfos.get(i);
            if(methodInfo.getEndTime() >= startTime && methodInfo.getEndTime() < endTime) {
                sortInfo.add(methodInfo);
            }
        }
        System.out.println("监控到方法名为：" + methodName + "的1分钟调用次数为：" + sortInfo.size());
        if(sortInfo.size() > 0) {
            sortInfo.sort((o1, o2) -> {
                if(o1.getCostTime() > o2.getCostTime()) {
                    return 1;
                } else if(o1.getCostTime() < o2.getCostTime()) {
                    return -1;
                } else {
                    return 0;
                }
            });

            int index = (int) (sortInfo.size() * rate);
            return sortInfo.get(index).getCostTime();
        }
        return null;

    }

    public class TPMonitorThread implements Runnable {

        @Override
        public void run() {
            try {
                Map<String, List<MethodInfo>> methodTimesMap = TPMonitorFilter.methodTimesMap;

                if(methodTimesMap.size() == 0) {
                    System.out.println("暂时还没有方法调用...");
                    return;
                }

                methodTimesMap.forEach((methodName, methodInfos) -> {
                    System.out.println("监控到方法名为：" + methodName +
                            "的TP90指标为：" + getTP(methodName, methodInfos, 0.9) +
                            ",TP99指标为：" + getTP(methodName, methodInfos, 0.99));
                    System.out.println("==================================================");
                });
                System.out.println("");
            } catch (Throwable e) {
                e.printStackTrace();
            }

        }
    }


}
