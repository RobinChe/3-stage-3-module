package com.robinche.bean;

public class MethodInfo {

    private String name;
    private long costTime;
    private long endTime;

    public MethodInfo(String name, long costTime, long endTime) {
        this.name = name;
        this.costTime = costTime;
        this.endTime = endTime;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public long getCostTime() {
        return costTime;
    }

    public void setCostTime(long costTime) {
        this.costTime = costTime;
    }

    public long getEndTime() {
        return endTime;
    }

    public void setEndTime(long endTime) {
        this.endTime = endTime;
    }
}
