package com.robin.service.impl;

import com.robinche.service.Task2Service;
import org.apache.dubbo.config.annotation.Service;

import java.util.Random;

/**
 * dubbo作业2
 *
 */
@Service
public class Task2ServiceImpl implements Task2Service {


    @Override
    public String methodA(String name) {
        sleepRandomTime();
        return "this is MethodA resp:" + name;
    }

    @Override
    public String methodB(String name) {
        sleepRandomTime();
        return "this is MethodB resp:" + name;
    }

    @Override
    public String methodC(String name) {
        sleepRandomTime();
        return "this is MethodC resp:" + name;
    }

    /**
     * 随机睡眠一定的时间  0~100ms之间
     */
    private void sleepRandomTime() {
        try {
            Thread.sleep(getRandomTimesIn100());
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    /**
     * 随机获取100ms以内的时间
     * @return
     */
    public long getRandomTimesIn100() {
        Random random = new Random();
        return random.nextInt(100);
    }



}
