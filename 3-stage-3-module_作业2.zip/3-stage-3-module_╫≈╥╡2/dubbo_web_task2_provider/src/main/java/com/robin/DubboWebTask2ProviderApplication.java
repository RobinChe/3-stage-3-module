package com.robin;

import org.apache.dubbo.config.spring.context.annotation.EnableDubbo;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
@EnableDubbo
public class DubboWebTask2ProviderApplication {

    public static void main(String[] args) {
        SpringApplication.run(DubboWebTask2ProviderApplication.class, args);
    }
}
